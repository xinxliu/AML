# Neighborhood-Components-Analysis-in-Python
A Python gradient-descent implementation of the Neighborhood Components Analysis (NCA) method for metric learning.

For a description and example of usage, see the [Jupyter notebook here](https://github.com/erlendd/Neighborhood-Components-Analysis-in-Python/blob/master/Neighborhood%20Components%20Analysis.ipynb)

